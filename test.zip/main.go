package main

import (
	"bytes"
	"fmt"
	"io"
	"log"
	"os/exec"
	"runtime"
	"time"
)

func main() {
	LuanguageGo()
	//LuanguageC()
	LuanguageCpp()
}

func LuanguageGo() {
	// go run code-user/main.go
	now := time.Now().UnixMilli()
	cmd := exec.Command("go", "run", "code-user/main.go")
	var out, stderr bytes.Buffer
	cmd.Stderr = &stderr
	cmd.Stdout = &out
	stdinPipe, err := cmd.StdinPipe()
	if err != nil {
		log.Fatalln(err)
	}
	io.WriteString(stdinPipe, "23 11\n")
	println("当前时间(毫秒) ==> ", now)
	if err := cmd.Run(); err != nil {
		log.Fatalln(err, stderr.String())
	}
	end := time.Now().UnixMilli()
	println("当前时间 ==> ", end)
	println("耗时 ==> ", end-now)
	println("Err:", string(stderr.Bytes()))
	fmt.Println(out.String())

	println(out.String() == "34\r\n")
	var em runtime.MemStats
	runtime.ReadMemStats(&em)
	fmt.Printf("KB: %v\n", em.Alloc/1024)
}

func LuanguageC() {
	// go run code-user/main.go
	now := time.Now().UnixMilli()
	exec.Command("gcc", "code-user/main.c", "-o", "test").Run()
	cmd := exec.Command("./test")
	var out, stderr bytes.Buffer
	cmd.Stderr = &stderr
	cmd.Stdout = &out
	stdinPipe, err := cmd.StdinPipe()
	if err != nil {
		log.Fatalln(err)
	}
	io.WriteString(stdinPipe, "23 11\n")
	println("当前时间(毫秒) ==> ", now)
	if err := cmd.Run(); err != nil {
		log.Fatalln(err, stderr.String())
	}
	end := time.Now().UnixMilli()
	println("当前时间 ==> ", end)
	println("耗时 ==> ", end-now)
	res := out.String()
	ans := "34\n"
	fmt.Println(res)
	data1 := []byte(res)
	fmt.Println(data1)
	fmt.Println(ans)
	data2 := []byte(ans)
	fmt.Println(data2)
	fmt.Println(res == ans)

	var em runtime.MemStats
	runtime.ReadMemStats(&em)
	fmt.Printf("KB: %v\n", em.Alloc/1024)
}

func LuanguageCpp() {
	// go run code-user/main.go
	now := time.Now().UnixMilli()
	exec.Command("g++", "code-user/main.cpp", "-o", "test").Run()
	cmd := exec.Command("./test")
	var out, stderr bytes.Buffer
	cmd.Stderr = &stderr
	cmd.Stdout = &out
	stdinPipe, err := cmd.StdinPipe()
	if err != nil {
		log.Fatalln(err)
	}
	io.WriteString(stdinPipe, "23 11\n")
	println("当前时间(毫秒) ==> ", now)
	if err := cmd.Run(); err != nil {
		log.Fatalln(err, stderr.String())
	}
	end := time.Now().UnixMilli()
	println("当前时间 ==> ", end)
	println("耗时 ==> ", end-now)
	res := out.String()
	ans := "34\r\n"
	fmt.Println(res)
	data1 := []byte(res)
	fmt.Println(data1)
	fmt.Println(ans)
	data2 := []byte(ans)
	fmt.Println(data2)
	fmt.Println(res == ans)

	var em runtime.MemStats
	runtime.ReadMemStats(&em)
	fmt.Printf("KB: %v\n", em.Alloc/1024)
}
