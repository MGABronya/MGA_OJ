package main

import "fmt"

func main() {
	var a, b int
	fmt.Scan(&a, &b)
	fmt.Print(a + b)
	fmt.Print("\n")
}
