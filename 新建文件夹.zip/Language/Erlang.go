// @Title  Erlang
// @Description  该文件提供关于Erlang文件的各种方法
// @Author  MGAronya（张健）
// @Update  MGAronya（张健）  2022-9-16 0:33
package Handle

import (
	"MGA_OJ/Interface"
	"os/exec"
)

// Erlang			定义了Erlang文件类
type Erlang struct{}

// @title    Compile
// @description   获得编译指令
// @auth      MGAronya（张健）       2022-9-16 12:15
// @param    ctx *gin.Context       接收一个上下文
// @return   void
func (e Erlang) Compile(path string, ID string) *exec.Cmd {
	return exec.Command("erlc", "-o", path, path+ID+".erl")
}

// @title    Chmod
// @description   获得权限
// @auth      MGAronya（张健）       2022-9-16 12:15
// @param    ctx *gin.Context       接收一个上下文
// @return   void
func (e Erlang) Chmod(path string, ID string) *exec.Cmd {
	return exec.Command("chmod", "755", path+ID+".beam")
}

// @title    Run
// @description   获得运行指令
// @auth      MGAronya（张健）       2022-9-16 12:15
// @param    ctx *gin.Context       接收一个上下文
// @return   void
func (e Erlang) Run(path string, ID string) *exec.Cmd {
	return exec.Command("erl", "-noshell", "-pa", path, "-s", ID, "start", "-s", "init", "stop")
}

// @title    Suffix
// @description   获得文件后缀
// @auth      MGAronya（张健）       2022-9-16 12:15
// @param    ctx *gin.Context       接收一个上下文
// @return   void
func (e Erlang) Suffix() string {
	return "erl"
}

// @title    TimeMultiplier
// @description   运行时间倍率
// @auth      MGAronya（张健）       2022-9-16 12:15
// @param    ctx *gin.Context       接收一个上下文
// @return   void
func (e Erlang) TimeMultiplier() uint {
	return 3
}

// @title    MemoryMultiplier
// @description   运行内存倍率
// @auth      MGAronya（张健）       2022-9-16 12:15
// @param    ctx *gin.Context       接收一个上下文
// @return   void
func (e Erlang) MemoryMultiplier() uint {
	return 2
}

// @title    RunUpTime
// @description   运行启动时间
// @auth      MGAronya（张健）       2022-9-16 12:15
// @param    ctx *gin.Context       接收一个上下文
// @return   void
func (e Erlang) RunUpTime() uint {
	return 3000
}

// @title    Name
// @description   获得文件名
// @auth      MGAronya（张健）       2022-9-16 12:15
// @param    ctx *gin.Context       接收一个上下文
// @return   void
func (e Erlang) Name() string {
	return "main"
}

// @title    NewErlang
// @description   新建一个CmdInterface
// @auth      MGAronya（张健）       2022-9-16 12:23
// @param    void
// @return   CmdInterface		返回一个CmdInterface用于调用各种函数
func NewErlang() Interface.CmdInterface {
	return Erlang{}
}
